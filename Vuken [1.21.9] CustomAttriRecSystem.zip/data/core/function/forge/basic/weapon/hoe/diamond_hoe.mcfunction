item modify entity @s weapon.mainhand [{function:set_components,components:{attribute_modifiers:[{amount:-0.8,id:base_attack_speed,operation:"add_value",type:attack_speed,slot:"mainhand"},{amount:3,id:base_attack_damage,operation:"add_value",type:attack_damage,slot:"mainhand"}],lore:[[{translate:lore.item.rarity.common,color:gray,italic:false,bold:false},{text:" "},{text:"☆☆☆",color:"#81ffcd",italic:false}]],custom_name:[{translate:lore.item.name.diamond_hoe,color:"#a8ebcf",italic:false,bold:true}],\
custom_data:{s_trigger:1b,attribute_modifiers:[\
[{amount:-0.8,id:base_attack_speed,operation:"add_value",type:attack_speed,slot:"mainhand"},{amount:3,id:base_attack_damage,operation:"add_value",type:attack_damage,slot:"mainhand"}],\
[{amount:-0.8,id:base_attack_speed,operation:"add_value",type:attack_speed,slot:"mainhand"},{amount:3,id:base_attack_damage,operation:"add_value",type:attack_damage,slot:"mainhand"}],\
[{amount:-0.8,id:base_attack_speed,operation:"add_value",type:attack_speed,slot:"mainhand"},{amount:3,id:base_attack_damage,operation:"add_value",type:attack_damage,slot:"mainhand"}],\
[{amount:-0.8,id:base_attack_speed,operation:"add_value",type:attack_speed,slot:"mainhand"},{amount:3,id:base_attack_damage,operation:"add_value",type:attack_damage,slot:"mainhand"}],\
[{amount:-0.8,id:base_attack_speed,operation:"add_value",type:attack_speed,slot:"mainhand"},{amount:3,id:base_attack_damage,operation:"add_value",type:attack_damage,slot:"mainhand"}]\
],enchantments:[\
{},{},{},{},{}\
],af_show:[\
"lore.item.intro.diamond_hoe.af_show.0",\
"lore.item.intro.diamond_hoe.af_show.1",\
"lore.item.intro.diamond_hoe.af_show.2",\
"lore.item.intro.diamond_hoe.af_show.3",\
"lore.item.intro.diamond_hoe.af_show.4"\
],pf_show:[\
"lore.item.intro.diamond_hoe.pf_show.0",\
"lore.item.intro.diamond_hoe.pf_show.1",\
"lore.item.intro.diamond_hoe.pf_show.2",\
"lore.item.intro.diamond_hoe.pf_show.3",\
"lore.item.intro.diamond_hoe.pf_show.4"\
]\
}}}]

###   "lore.item.intro.diamond_hoe.af_show.0":"",
###   "lore.item.intro.diamond_hoe.af_show.1":"",
###   "lore.item.intro.diamond_hoe.af_show.2":"",
###   "lore.item.intro.diamond_hoe.af_show.3":"",
###   "lore.item.intro.diamond_hoe.af_show.4":"",
###   "lore.item.intro.diamond_hoe.pf_show.0":"",
###   "lore.item.intro.diamond_hoe.pf_show.1":"",
###   "lore.item.intro.diamond_hoe.pf_show.2":"",
###   "lore.item.intro.diamond_hoe.pf_show.3":"",
###   "lore.item.intro.diamond_hoe.pf_show.4":"",
###   "lore.item.name.diamond_hoe":"源始钻石镰刀",