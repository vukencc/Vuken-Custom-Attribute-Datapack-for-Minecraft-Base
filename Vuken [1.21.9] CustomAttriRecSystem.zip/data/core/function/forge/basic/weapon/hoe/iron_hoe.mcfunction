item modify entity @s weapon.mainhand [{function:set_components,components:{attribute_modifiers:[{amount:-1.2,id:base_attack_speed,operation:"add_value",type:attack_speed,slot:"mainhand"},{amount:2.5,id:base_attack_damage,operation:"add_value",type:attack_damage,slot:"mainhand"}],lore:[[{translate:lore.item.rarity.common,color:gray,italic:false,bold:false},{text:" "},{text:"☆☆☆",color:"#81ffcd",italic:false}]],custom_name:[{translate:lore.item.name.iron_hoe,color:"#a8ebcf",italic:false,bold:true}],\
custom_data:{s_trigger:1b,attribute_modifiers:[\
[{amount:-1.2,id:base_attack_speed,operation:"add_value",type:attack_speed,slot:"mainhand"},{amount:2.5,id:base_attack_damage,operation:"add_value",type:attack_damage,slot:"mainhand"}],\
[{amount:-1.2,id:base_attack_speed,operation:"add_value",type:attack_speed,slot:"mainhand"},{amount:2.5,id:base_attack_damage,operation:"add_value",type:attack_damage,slot:"mainhand"}],\
[{amount:-1.2,id:base_attack_speed,operation:"add_value",type:attack_speed,slot:"mainhand"},{amount:2.5,id:base_attack_damage,operation:"add_value",type:attack_damage,slot:"mainhand"}],\
[{amount:-1.2,id:base_attack_speed,operation:"add_value",type:attack_speed,slot:"mainhand"},{amount:2.5,id:base_attack_damage,operation:"add_value",type:attack_damage,slot:"mainhand"}],\
[{amount:-1.2,id:base_attack_speed,operation:"add_value",type:attack_speed,slot:"mainhand"},{amount:2.5,id:base_attack_damage,operation:"add_value",type:attack_damage,slot:"mainhand"}]\
],enchantments:[\
{},{},{},{},{}\
],af_show:[\
"lore.item.intro.iron_hoe.af_show.0",\
"lore.item.intro.iron_hoe.af_show.1",\
"lore.item.intro.iron_hoe.af_show.2",\
"lore.item.intro.iron_hoe.af_show.3",\
"lore.item.intro.update.none"\
],pf_show:[\
"lore.item.intro.iron_hoe.pf_show.0",\
"lore.item.intro.iron_hoe.pf_show.1",\
"lore.item.intro.iron_hoe.pf_show.2",\
"lore.item.intro.iron_hoe.pf_show.3",\
"lore.item.intro.update.none"\
]\
}}}]

###   "lore.item.intro.iron_hoe.af_show.0":"",
###   "lore.item.intro.iron_hoe.af_show.1":"",
###   "lore.item.intro.iron_hoe.af_show.2":"",
###   "lore.item.intro.iron_hoe.af_show.3":"",
###   "lore.item.intro.iron_hoe.pf_show.0":"",
###   "lore.item.intro.iron_hoe.pf_show.1":"",
###   "lore.item.intro.iron_hoe.pf_show.2":"",
###   "lore.item.intro.iron_hoe.pf_show.3":"",
###   "lore.item.name.iron_hoe":"源始铁镰刀",