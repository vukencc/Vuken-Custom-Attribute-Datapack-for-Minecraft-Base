item modify entity @s armor.feet [{function:set_components,components:{attribute_modifiers:[{amount:3,id:"feet_armor",operation:"add_value",type:"armor",slot:"feet"},{amount:2,id:"feet_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"feet"}],lore:[[{translate:lore.item.rarity.common,color:gray,italic:false,bold:false},{text:" "},{text:"☆☆☆",color:"#81ffcd",italic:false}]],custom_name:[{translate:lore.item.name.diamond_boots,color:"#a8ebcf",italic:false,bold:true}],\
custom_data:{s_pas:1b,attribute_modifiers:[\
[{amount:3,id:"feet_armor",operation:"add_value",type:"armor",slot:"feet"},{amount:2,id:"feet_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"feet"}],\
[{amount:3,id:"feet_armor",operation:"add_value",type:"armor",slot:"feet"},{amount:2,id:"feet_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"feet"}],\
[{amount:3,id:"feet_armor",operation:"add_value",type:"armor",slot:"feet"},{amount:2,id:"feet_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"feet"}],\
[{amount:3,id:"feet_armor",operation:"add_value",type:"armor",slot:"feet"},{amount:2,id:"feet_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"feet"}],\
[{amount:3,id:"feet_armor",operation:"add_value",type:"armor",slot:"feet"},{amount:2,id:"feet_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"feet"}]\
],enchantments:[\
{},{},{},{},{}\
],af_show:[\
"lore.item.intro.diamond_boots.af_show.0",\
"lore.item.intro.diamond_boots.af_show.1",\
"lore.item.intro.diamond_boots.af_show.2",\
"lore.item.intro.diamond_boots.af_show.3",\
"lore.item.intro.diamond_boots.af_show.4"\
],pf_show:[\
"lore.item.intro.diamond_boots.pf_show.0",\
"lore.item.intro.diamond_boots.pf_show.1",\
"lore.item.intro.diamond_boots.pf_show.2",\
"lore.item.intro.diamond_boots.pf_show.3",\
"lore.item.intro.diamond_boots.pf_show.4"\
]\
}}}]

###   "lore.item.intro.diamond_boots.af_show.0":"",
###   "lore.item.intro.diamond_boots.af_show.1":"",
###   "lore.item.intro.diamond_boots.af_show.2":"",
###   "lore.item.intro.diamond_boots.af_show.3":"",
###   "lore.item.intro.diamond_boots.af_show.4":"",
###   "lore.item.intro.diamond_boots.pf_show.0":"",
###   "lore.item.intro.diamond_boots.pf_show.1":"",
###   "lore.item.intro.diamond_boots.pf_show.2":"",
###   "lore.item.intro.diamond_boots.pf_show.3":"",
###   "lore.item.intro.diamond_boots.pf_show.4":"",
###   "lore.item.name.diamond_boots":"源始钻石靴子",