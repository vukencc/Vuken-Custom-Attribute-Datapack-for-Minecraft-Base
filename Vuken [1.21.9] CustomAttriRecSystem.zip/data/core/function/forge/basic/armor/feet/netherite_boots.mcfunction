item modify entity @s armor.feet [{function:set_components,components:{attribute_modifiers:[{amount:3,id:"feet_armor",operation:"add_value",type:"armor",slot:"feet"},{amount:3,id:"feet_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"feet"},{amount:1,id:"feet_knockback_resistance",operation:"add_value",type:"knockback_resistance",slot:"feet"}],lore:[[{translate:lore.item.rarity.common,color:gray,italic:false,bold:false},{text:" "},{text:"☆☆☆",color:"#81ffcd",italic:false}]],custom_name:[{translate:lore.item.name.netherite_boots,color:"#a8ebcf",italic:false,bold:true}],\
custom_data:{s_pas:1b,attribute_modifiers:[\
[{amount:3,id:"feet_armor",operation:"add_value",type:"armor",slot:"feet"},{amount:3,id:"feet_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"feet"},{amount:1,id:"feet_knockback_resistance",operation:"add_value",type:"knockback_resistance",slot:"feet"}],\
[{amount:3,id:"feet_armor",operation:"add_value",type:"armor",slot:"feet"},{amount:3,id:"feet_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"feet"},{amount:1,id:"feet_knockback_resistance",operation:"add_value",type:"knockback_resistance",slot:"feet"}],\
[{amount:3,id:"feet_armor",operation:"add_value",type:"armor",slot:"feet"},{amount:3,id:"feet_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"feet"},{amount:1,id:"feet_knockback_resistance",operation:"add_value",type:"knockback_resistance",slot:"feet"}],\
[{amount:3,id:"feet_armor",operation:"add_value",type:"armor",slot:"feet"},{amount:3,id:"feet_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"feet"},{amount:1,id:"feet_knockback_resistance",operation:"add_value",type:"knockback_resistance",slot:"feet"}],\
[{amount:3,id:"feet_armor",operation:"add_value",type:"armor",slot:"feet"},{amount:3,id:"feet_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"feet"},{amount:1,id:"feet_knockback_resistance",operation:"add_value",type:"knockback_resistance",slot:"feet"}]\
],enchantments:[\
{},{},{},{},{}\
],af_show:[\
"lore.item.intro.netherite_boots.af_show.0",\
"lore.item.intro.netherite_boots.af_show.1",\
"lore.item.intro.netherite_boots.af_show.2",\
"lore.item.intro.netherite_boots.af_show.3",\
"lore.item.intro.netherite_boots.af_show.4"\
],pf_show:[\
"lore.item.intro.netherite_boots.pf_show.0",\
"lore.item.intro.netherite_boots.pf_show.1",\
"lore.item.intro.netherite_boots.pf_show.2",\
"lore.item.intro.netherite_boots.pf_show.3",\
"lore.item.intro.netherite_boots.pf_show.4"\
]\
}}}]

###   "lore.item.intro.netherite_boots.af_show.0":"",
###   "lore.item.intro.netherite_boots.af_show.1":"",
###   "lore.item.intro.netherite_boots.af_show.2":"",
###   "lore.item.intro.netherite_boots.af_show.3":"",
###   "lore.item.intro.netherite_boots.af_show.4":"",
###   "lore.item.intro.netherite_boots.pf_show.0":"",
###   "lore.item.intro.netherite_boots.pf_show.1":"",
###   "lore.item.intro.netherite_boots.pf_show.2":"",
###   "lore.item.intro.netherite_boots.pf_show.3":"",
###   "lore.item.intro.netherite_boots.pf_show.4":"",
###   "lore.item.name.netherite_boots":"源始下界合金靴子",