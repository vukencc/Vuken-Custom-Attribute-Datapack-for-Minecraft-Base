item modify entity @s armor.feet [{function:set_components,components:{attribute_modifiers:[{amount:1,id:"feet_armor",operation:"add_value",type:"armor",slot:"feet"}],lore:[[{translate:lore.item.rarity.common,color:gray,italic:false,bold:false},{text:" "},{text:"☆☆☆",color:"#81ffcd",italic:false}]],custom_name:[{translate:lore.item.name.leather_boots,color:"#a8ebcf",italic:false,bold:true}],\
custom_data:{s_pas:1b,attribute_modifiers:[\
[{amount:1,id:"feet_armor",operation:"add_value",type:"armor",slot:"feet"}],\
[{amount:1,id:"feet_armor",operation:"add_value",type:"armor",slot:"feet"}],\
[{amount:1,id:"feet_armor",operation:"add_value",type:"armor",slot:"feet"}],\
[{amount:1,id:"feet_armor",operation:"add_value",type:"armor",slot:"feet"}],\
[{amount:1,id:"feet_armor",operation:"add_value",type:"armor",slot:"feet"}]\
],enchantments:[\
{},{},{},{},{}\
],af_show:[\
"lore.item.intro.leather_boots.af_show.0",\
"lore.item.intro.leather_boots.af_show.1",\
"lore.item.intro.update.none",\
"lore.item.intro.update.none",\
"lore.item.intro.update.none"\
],pf_show:[\
"lore.item.intro.leather_boots.pf_show.0",\
"lore.item.intro.leather_boots.pf_show.1",\
"lore.item.intro.update.none",\
"lore.item.intro.update.none",\
"lore.item.intro.update.none"\
]\
}}}]

###   "lore.item.intro.leather_boots.af_show.0":"",
###   "lore.item.intro.leather_boots.af_show.1":"",
###   "lore.item.intro.leather_boots.pf_show.0":"",
###   "lore.item.intro.leather_boots.pf_show.1":"",
###   "lore.item.name.leather_boots":"源始皮革靴子",