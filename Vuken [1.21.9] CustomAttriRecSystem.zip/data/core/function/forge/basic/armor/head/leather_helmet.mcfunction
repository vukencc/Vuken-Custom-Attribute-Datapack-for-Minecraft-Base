item modify entity @s armor.head [{function:set_components,components:{attribute_modifiers:[{amount:1,id:"head_armor",operation:"add_value",type:"armor",slot:"head"}],lore:[[{translate:lore.item.rarity.common,color:gray,italic:false,bold:false},{text:" "},{text:"☆☆☆",color:"#81ffcd",italic:false}]],custom_name:[{translate:lore.item.name.leather_helmet,color:"#a8ebcf",italic:false,bold:true}],\
custom_data:{s_pas:1b,attribute_modifiers:[\
[{amount:1,id:"head_armor",operation:"add_value",type:"armor",slot:"head"}],\
[{amount:1,id:"head_armor",operation:"add_value",type:"armor",slot:"head"}],\
[{amount:1,id:"head_armor",operation:"add_value",type:"armor",slot:"head"}],\
[{amount:1,id:"head_armor",operation:"add_value",type:"armor",slot:"head"}],\
[{amount:1,id:"head_armor",operation:"add_value",type:"armor",slot:"head"}]\
],enchantments:[\
{}, \
{}, \
{}, \
{}, \
{}\
],af_show:[\
"lore.item.intro.leather_helmet.af_show.0",\
"lore.item.intro.leather_helmet.af_show.1",\
"lore.item.intro.update.none",\
"lore.item.intro.update.none",\
"lore.item.intro.update.none"\
],pf_show:[\
"lore.item.intro.leather_helmet.pf_show.0",\
"lore.item.intro.leather_helmet.pf_show.1",\
"lore.item.intro.update.none",\
"lore.item.intro.update.none",\
"lore.item.intro.update.none"\
]\
}}}]

###   "lore.item.intro.leather_helmet.af_show.0":"-5% 所受伤害",
###   "lore.item.intro.leather_helmet.af_show.1":"+1 最大生命值",
###   "lore.item.intro.leather_helmet.pf_show.0":"+1 保护",
###   "lore.item.intro.leather_helmet.pf_show.1":"+1 水下呼吸",
###   "lore.item.name.leather_helmet":"源始皮革帽子",
