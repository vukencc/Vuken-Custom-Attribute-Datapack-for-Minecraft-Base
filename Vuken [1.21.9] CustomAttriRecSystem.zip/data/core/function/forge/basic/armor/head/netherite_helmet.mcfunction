item modify entity @s armor.head [{function:set_components,components:{attribute_modifiers:[{amount:3,id:"head_armor",operation:"add_value",type:"armor",slot:"head"},{amount:3,id:"head_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"head"},{amount:1,id:"head_knockback_resistance",operation:"add_value",type:"knockback_resistance",slot:"head"}],lore:[[{translate:lore.item.rarity.common,color:gray,italic:false,bold:false},{text:" "},{text:"☆☆☆",color:"#81ffcd",italic:false}]],custom_name:[{translate:lore.item.name.netherite_helmet,color:"#a8ebcf",italic:false,bold:true}],\
custom_data:{s_pas:1b,attribute_modifiers:[\
[{amount:3,id:"head_armor",operation:"add_value",type:"armor",slot:"head"},{amount:3,id:"head_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"head"},{amount:1,id:"head_knockback_resistance",operation:"add_value",type:"knockback_resistance",slot:"head"}],\
[{amount:3,id:"head_armor",operation:"add_value",type:"armor",slot:"head"},{amount:3,id:"head_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"head"},{amount:1,id:"head_knockback_resistance",operation:"add_value",type:"knockback_resistance",slot:"head"}],\
[{amount:3,id:"head_armor",operation:"add_value",type:"armor",slot:"head"},{amount:3,id:"head_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"head"},{amount:1,id:"head_knockback_resistance",operation:"add_value",type:"knockback_resistance",slot:"head"}],\
[{amount:3,id:"head_armor",operation:"add_value",type:"armor",slot:"head"},{amount:3,id:"head_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"head"},{amount:1,id:"head_knockback_resistance",operation:"add_value",type:"knockback_resistance",slot:"head"}],\
[{amount:3,id:"head_armor",operation:"add_value",type:"armor",slot:"head"},{amount:3,id:"head_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"head"},{amount:1,id:"head_knockback_resistance",operation:"add_value",type:"knockback_resistance",slot:"head"}]\
],enchantments:[\
{},{},{},{},{}\
],af_show:[\
"lore.item.intro.netherite_helmet.af_show.0",\
"lore.item.intro.netherite_helmet.af_show.1",\
"lore.item.intro.netherite_helmet.af_show.2",\
"lore.item.intro.netherite_helmet.af_show.3",\
"lore.item.intro.netherite_helmet.af_show.4"\
],pf_show:[\
"lore.item.intro.netherite_helmet.pf_show.0",\
"lore.item.intro.netherite_helmet.pf_show.1",\
"lore.item.intro.netherite_helmet.pf_show.2",\
"lore.item.intro.netherite_helmet.pf_show.3",\
"lore.item.intro.netherite_helmet.pf_show.4"\
]\
}}}]

###   "lore.item.intro.netherite_helmet.af_show.0":"",
###   "lore.item.intro.netherite_helmet.af_show.1":"",
###   "lore.item.intro.netherite_helmet.af_show.2":"",
###   "lore.item.intro.netherite_helmet.af_show.3":"",
###   "lore.item.intro.netherite_helmet.af_show.4":"",
###   "lore.item.intro.netherite_helmet.pf_show.0":"",
###   "lore.item.intro.netherite_helmet.pf_show.1":"",
###   "lore.item.intro.netherite_helmet.pf_show.2":"",
###   "lore.item.intro.netherite_helmet.pf_show.3":"",
###   "lore.item.intro.netherite_helmet.pf_show.4":"",
###   "lore.item.name.netherite_helmet":"源始下界合金头盔",