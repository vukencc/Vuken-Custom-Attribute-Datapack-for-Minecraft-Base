item modify entity @s armor.legs [{function:set_components,components:{attribute_modifiers:[{amount:3,id:"legs_armor",operation:"add_value",type:"armor",slot:"legs"}],lore:[[{translate:lore.item.rarity.common,color:gray,italic:false,bold:false},{text:" "},{text:"☆☆☆",color:"#81ffcd",italic:false}]],custom_name:[{translate:lore.item.name.golden_leggings,color:"#a8ebcf",italic:false,bold:true}],\
custom_data:{s_pas:1b,attribute_modifiers:[\
[{amount:3,id:"legs_armor",operation:"add_value",type:"armor",slot:"legs"}],\
[{amount:3,id:"legs_armor",operation:"add_value",type:"armor",slot:"legs"}],\
[{amount:3,id:"legs_armor",operation:"add_value",type:"armor",slot:"legs"}],\
[{amount:3,id:"legs_armor",operation:"add_value",type:"armor",slot:"legs"}],\
[{amount:3,id:"legs_armor",operation:"add_value",type:"armor",slot:"legs"}]\
],enchantments:[\
{},{},{},{},{}\
],af_show:[\
"lore.item.intro.golden_leggings.af_show.0",\
"lore.item.intro.golden_leggings.af_show.1",\
"lore.item.intro.update.none",\
"lore.item.intro.update.none",\
"lore.item.intro.update.none"\
],pf_show:[\
"lore.item.intro.golden_leggings.pf_show.0",\
"lore.item.intro.golden_leggings.pf_show.1",\
"lore.item.intro.update.none",\
"lore.item.intro.update.none",\
"lore.item.intro.update.none"\
]\
}}}]

###   "lore.item.intro.golden_leggings.af_show.0":"",
###   "lore.item.intro.golden_leggings.af_show.1":"",
###   "lore.item.intro.golden_leggings.pf_show.0":"",
###   "lore.item.intro.golden_leggings.pf_show.1":"",
###   "lore.item.name.golden_leggings":"源始金护腿",