item modify entity @s armor.legs [{function:set_components,components:{attribute_modifiers:[{amount:6,id:"legs_armor",operation:"add_value",type:"armor",slot:"legs"},{amount:3,id:"legs_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"legs"},{amount:1,id:"legs_knockback_resistance",operation:"add_value",type:"knockback_resistance",slot:"legs"}],lore:[[{translate:lore.item.rarity.common,color:gray,italic:false,bold:false},{text:" "},{text:"☆☆☆",color:"#81ffcd",italic:false}]],custom_name:[{translate:lore.item.name.netherite_leggings,color:"#a8ebcf",italic:false,bold:true}],\
custom_data:{s_pas:1b,attribute_modifiers:[\
[{amount:6,id:"legs_armor",operation:"add_value",type:"armor",slot:"legs"},{amount:3,id:"legs_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"legs"},{amount:1,id:"legs_knockback_resistance",operation:"add_value",type:"knockback_resistance",slot:"legs"}],\
[{amount:6,id:"legs_armor",operation:"add_value",type:"armor",slot:"legs"},{amount:3,id:"legs_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"legs"},{amount:1,id:"legs_knockback_resistance",operation:"add_value",type:"knockback_resistance",slot:"legs"}],\
[{amount:6,id:"legs_armor",operation:"add_value",type:"armor",slot:"legs"},{amount:3,id:"legs_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"legs"},{amount:1,id:"legs_knockback_resistance",operation:"add_value",type:"knockback_resistance",slot:"legs"}],\
[{amount:6,id:"legs_armor",operation:"add_value",type:"armor",slot:"legs"},{amount:3,id:"legs_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"legs"},{amount:1,id:"legs_knockback_resistance",operation:"add_value",type:"knockback_resistance",slot:"legs"}],\
[{amount:6,id:"legs_armor",operation:"add_value",type:"armor",slot:"legs"},{amount:3,id:"legs_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"legs"},{amount:1,id:"legs_knockback_resistance",operation:"add_value",type:"knockback_resistance",slot:"legs"}]\
],enchantments:[\
{},{},{},{},{}\
],af_show:[\
"lore.item.intro.netherite_leggings.af_show.0",\
"lore.item.intro.netherite_leggings.af_show.1",\
"lore.item.intro.netherite_leggings.af_show.2",\
"lore.item.intro.netherite_leggings.af_show.3",\
"lore.item.intro.netherite_leggings.af_show.4"\
],pf_show:[\
"lore.item.intro.netherite_leggings.pf_show.0",\
"lore.item.intro.netherite_leggings.pf_show.1",\
"lore.item.intro.netherite_leggings.pf_show.2",\
"lore.item.intro.netherite_leggings.pf_show.3",\
"lore.item.intro.netherite_leggings.pf_show.4"\
]\
}}}]

###   "lore.item.intro.netherite_leggings.af_show.0":"",
###   "lore.item.intro.netherite_leggings.af_show.1":"",
###   "lore.item.intro.netherite_leggings.af_show.2":"",
###   "lore.item.intro.netherite_leggings.af_show.3":"",
###   "lore.item.intro.netherite_leggings.af_show.4":"",
###   "lore.item.intro.netherite_leggings.pf_show.0":"",
###   "lore.item.intro.netherite_leggings.pf_show.1":"",
###   "lore.item.intro.netherite_leggings.pf_show.2":"",
###   "lore.item.intro.netherite_leggings.pf_show.3":"",
###   "lore.item.intro.netherite_leggings.pf_show.4":"",
###   "lore.item.name.netherite_leggings":"源始下界合金护腿",