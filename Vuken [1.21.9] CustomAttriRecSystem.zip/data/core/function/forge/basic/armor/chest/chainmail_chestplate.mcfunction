item modify entity @s armor.chest [{function:set_components,components:{attribute_modifiers:[{amount:5,id:"chest_armor",operation:"add_value",type:"armor",slot:"chest"}],lore:[[{translate:lore.item.rarity.common,color:gray,italic:false,bold:false},{text:" "},{text:"☆☆☆",color:"#81ffcd",italic:false}]],custom_name:[{translate:lore.item.name.chainmail_chestplate,color:"#a8ebcf",italic:false,bold:true}],\
custom_data:{s_pas:1b,attribute_modifiers:[\
[{amount:5,id:"chest_armor",operation:"add_value",type:"armor",slot:"chest"}],\
[{amount:5,id:"chest_armor",operation:"add_value",type:"armor",slot:"chest"}],\
[{amount:5,id:"chest_armor",operation:"add_value",type:"armor",slot:"chest"}],\
[{amount:5,id:"chest_armor",operation:"add_value",type:"armor",slot:"chest"}],\
[{amount:5,id:"chest_armor",operation:"add_value",type:"armor",slot:"chest"}]\
],enchantments:[\
{},{},{},{},{}\
],af_show:[\
"lore.item.intro.chainmail_chestplate.af_show.0",\
"lore.item.intro.chainmail_chestplate.af_show.1",\
"lore.item.intro.chainmail_chestplate.af_show.2",\
"lore.item.intro.update.none",\
"lore.item.intro.update.none"\
],pf_show:[\
"lore.item.intro.chainmail_chestplate.pf_show.0",\
"lore.item.intro.chainmail_chestplate.pf_show.1",\
"lore.item.intro.chainmail_chestplate.pf_show.2",\
"lore.item.intro.update.none",\
"lore.item.intro.update.none"\
]\
}}}]

###   "lore.item.intro.chainmail_chestplate.af_show.0":"",
###   "lore.item.intro.chainmail_chestplate.af_show.1":"",
###   "lore.item.intro.chainmail_chestplate.af_show.2":"",
###   "lore.item.intro.chainmail_chestplate.pf_show.0":"",
###   "lore.item.intro.chainmail_chestplate.pf_show.1":"",
###   "lore.item.intro.chainmail_chestplate.pf_show.2":"",
###   "lore.item.name.chainmail_chestplate":"源始锁链胸甲",