item modify entity @s armor.chest [{function:set_components,components:{attribute_modifiers:[{amount:8,id:"chest_armor",operation:"add_value",type:"armor",slot:"chest"},{amount:2,id:"chest_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"chest"}],lore:[[{translate:lore.item.rarity.common,color:gray,italic:false,bold:false},{text:" "},{text:"☆☆☆",color:"#81ffcd",italic:false}]],custom_name:[{translate:lore.item.name.diamond_chestplate,color:"#a8ebcf",italic:false,bold:true}],\
custom_data:{s_pas:1b,attribute_modifiers:[\
[{amount:8,id:"chest_armor",operation:"add_value",type:"armor",slot:"chest"},{amount:2,id:"chest_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"chest"}],\
[{amount:8,id:"chest_armor",operation:"add_value",type:"armor",slot:"chest"},{amount:2,id:"chest_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"chest"}],\
[{amount:8,id:"chest_armor",operation:"add_value",type:"armor",slot:"chest"},{amount:2,id:"chest_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"chest"}],\
[{amount:8,id:"chest_armor",operation:"add_value",type:"armor",slot:"chest"},{amount:2,id:"chest_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"chest"}],\
[{amount:8,id:"chest_armor",operation:"add_value",type:"armor",slot:"chest"},{amount:2,id:"chest_armor_toughness",operation:"add_value",type:"armor_toughness",slot:"chest"}]\
],enchantments:[\
{},{},{},{},{}\
],af_show:[\
"lore.item.intro.diamond_chestplate.af_show.0",\
"lore.item.intro.diamond_chestplate.af_show.1",\
"lore.item.intro.diamond_chestplate.af_show.2",\
"lore.item.intro.diamond_chestplate.af_show.3",\
"lore.item.intro.diamond_chestplate.af_show.4"\
],pf_show:[\
"lore.item.intro.diamond_chestplate.pf_show.0",\
"lore.item.intro.diamond_chestplate.pf_show.1",\
"lore.item.intro.diamond_chestplate.pf_show.2",\
"lore.item.intro.diamond_chestplate.pf_show.3",\
"lore.item.intro.diamond_chestplate.pf_show.4"\
]\
}}}]

###   "lore.item.intro.diamond_chestplate.af_show.0":"",
###   "lore.item.intro.diamond_chestplate.af_show.1":"",
###   "lore.item.intro.diamond_chestplate.af_show.2":"",
###   "lore.item.intro.diamond_chestplate.af_show.3":"",
###   "lore.item.intro.diamond_chestplate.af_show.4":"",
###   "lore.item.intro.diamond_chestplate.pf_show.0":"",
###   "lore.item.intro.diamond_chestplate.pf_show.1":"",
###   "lore.item.intro.diamond_chestplate.pf_show.2":"",
###   "lore.item.intro.diamond_chestplate.pf_show.3":"",
###   "lore.item.intro.diamond_chestplate.pf_show.4":"",
###   "lore.item.name.diamond_chestplate":"源始钻石胸甲",