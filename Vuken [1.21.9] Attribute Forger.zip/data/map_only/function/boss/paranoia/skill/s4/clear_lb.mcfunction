particle end_rod ~ ~1.5 ~ 3 3 3 0.2 30 normal
tag @s remove Boss_1_s4_lb
data merge entity @n[type=item_display,tag=Boss_1_AS_Modified_lb] {Glowing:false}
tag @n[type=item_display,tag=Boss_1_AS_Modified_lb] remove Boss_1_AS_Modified
tag @n[type=item_display,tag=Boss_1_AS_Modified_lb] remove Boss_1_AS_Modified_lb